#!/bin/bash
cd sample1-output-annotate
cd scaffold-26
blastp -query scaffold-26-proteins.faa -db /research/saima5/virome-project/blast-db/nr -evalue 1e-5 -max_target_seqs 3 -num_threads 16 -outfmt '7' -out blastp-output.txt
